package com.niit.Luvbro.dao;

import com.niit.Luvbro.model.Billing;

//import java.util.List;

public interface BillingDao 
{
	public boolean saveOrUpdate(Billing billing);
	public boolean delete(Billing billing);
//	public Billing getBilling(int id);
//	public List<Billing> list();

}
