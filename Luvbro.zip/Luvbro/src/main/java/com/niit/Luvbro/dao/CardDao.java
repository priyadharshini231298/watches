package com.niit.Luvbro.dao;

import com.niit.Luvbro.model.Card;

//import java.util.List;

public interface CardDao 
{
	public boolean saveOrUpdate(Card card);
	public boolean delete(Card card);
//	public Card getCard(int id);
//	public List<Card> list();

}
