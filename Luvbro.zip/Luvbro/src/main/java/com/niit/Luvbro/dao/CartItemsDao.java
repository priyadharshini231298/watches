package com.niit.Luvbro.dao;

import com.niit.Luvbro.model.CartItems;

//import java.util.List;

public interface CartItemsDao 
{
	public boolean saveOrUpdate(CartItems cartitems);
	public boolean delete(CartItems cartitems);
//	public CartItems getCartItems(int id);
//	public List<CartItems> list();

}
