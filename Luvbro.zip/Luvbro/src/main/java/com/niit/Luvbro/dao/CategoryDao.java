package com.niit.Luvbro.dao;

import com.niit.Luvbro.model.Category;

//import java.util.List;

public interface CategoryDao 
{
	public boolean saveOrUpdate(Category category);
	public boolean delete(Category category);
//	public Category getCategory(int id);
//	public List<Category> list();

}
