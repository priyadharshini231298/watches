package com.niit.Luvbro.dao;



import com.niit.Luvbro.model.Order;

public interface OrderDao 
{
	public boolean saveOrUpdate(Order order);
	public boolean delete(Order order);
//	public Order getOrder(int id);
//	public List<Order> list();

}
