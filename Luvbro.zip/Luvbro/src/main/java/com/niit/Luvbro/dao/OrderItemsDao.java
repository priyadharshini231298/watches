package com.niit.Luvbro.dao;

import com.niit.Luvbro.model.OrderItems;

//import java.util.List;

public interface OrderItemsDao 
{
	public boolean saveOrUpdate(OrderItems orderitems);
	public boolean delete(OrderItems orderitems);
//	public OrderItems getOrderItems(int id);
//	public List<OrderItems> list();

}
