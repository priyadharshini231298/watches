package com.niit.Luvbro.dao;
import com.niit.Luvbro.model.Product;

//import java.util.List;

public interface ProductDao
{
	public boolean saveOrUpdate(Product product);
	public boolean delete(Product product);
//	public Product getProduct(int id);
//	public List<Product> list();

}

