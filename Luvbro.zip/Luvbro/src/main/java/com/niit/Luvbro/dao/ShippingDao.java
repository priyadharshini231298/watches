package com.niit.Luvbro.dao;

import com.niit.Luvbro.model.Shipping;

//import java.util.List;

public interface ShippingDao 
{
	public boolean saveOrUpdate(Shipping shipping);
	public boolean delete(Shipping shipping);
//	public Shipping getShipping(int id);
//	public List<Shipping> list();

}
