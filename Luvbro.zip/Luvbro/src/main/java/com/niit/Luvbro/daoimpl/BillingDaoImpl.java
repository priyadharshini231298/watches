package com.niit.Luvbro.daoimpl;



//import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.niit.Luvbro.dao.BillingDao;
//import com.niit.Luvbro.dao.BillingDao;
import com.niit.Luvbro.model.Billing;
//import com.niit.Luvbro.model.Product;

@Repository("billingDao")
@EnableTransactionManagement
@Transactional
public class BillingDaoImpl implements BillingDao 
{
  @Autowired
  private SessionFactory sessionFactory ;

	 public BillingDaoImpl(SessionFactory sessionFactory)
	 {
		 this.sessionFactory = sessionFactory;
	 }

	public boolean saveOrUpdate(Billing billing) 
	{
	  try
	  {
	   sessionFactory.getCurrentSession().saveOrUpdate(billing);
	    return true;
	  }
	  catch(Exception E)
	  {
		  return false;
	  }
	}


	public boolean delete(Billing billing)
	{
		try
		  {
		   sessionFactory.getCurrentSession().delete(billing);
		    return true;
		  }
		  catch(Exception E)
		  {
			  return false;
		  }
	}
//
//	
//	public Billing getBilling(int id) 
//	{
//		if(billing.getC_id()==id)
//			return billing;
//		return null;
//	}
//
//	
//	public List<Billing> list() {
//		return null;
//	}

}

