package com.niit.Luvbro.daoimpl;



//import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.niit.Luvbro.dao.CategoryDao;
import com.niit.Luvbro.model.Category;
//import com.niit.Luvbro.model.Product;

@Repository("categoryDao")
@EnableTransactionManagement
@Transactional
public class CategoryDaoImpl implements CategoryDao 
{
  @Autowired
  private SessionFactory sessionFactory ;

	 public CategoryDaoImpl(SessionFactory sessionFactory)
	 {
		 this.sessionFactory = sessionFactory;
	 }

	public boolean saveOrUpdate(Category category) 
	{
	  try
	  {
	   sessionFactory.getCurrentSession().saveOrUpdate(category);
	    return true;
	  }
	  catch(Exception E)
	  {
		  return false;
	  }
	}


	public boolean delete(Category category)
	{
		try
		  {
		   sessionFactory.getCurrentSession().delete(category);
		    return true;
		  }
		  catch(Exception E)
		  {
			  return false;
		  }
	}
//
//	
//	public Category getCategory(int id) 
//	{
//		if(category.getC_id()==id)
//			return category;
//		return null;
//	}
//
//	
//	public List<Category> list() {
//		return null;
//	}

}
