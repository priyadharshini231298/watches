package com.niit.Luvbro.daoimpl;



//import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.niit.Luvbro.dao.OrderDao;
import com.niit.Luvbro.model.Order;
//import com.niit.Luvbro.model.Product;

@Repository("orderDao")
@EnableTransactionManagement
@Transactional
public class OrderDaoImpl implements OrderDao 
{
  @Autowired
  private SessionFactory sessionFactory ;

	 public OrderDaoImpl(SessionFactory sessionFactory)
	 {
		 this.sessionFactory = sessionFactory;
	 }

	public boolean saveOrUpdate(Order order) 
	{
	  try
	  {
	   sessionFactory.getCurrentSession().saveOrUpdate(order);
	    return true;
	  }
	  catch(Exception E)
	  {
		  return false;
	  }
	}


	public boolean delete(Order order)
	{
		try
		  {
		   sessionFactory.getCurrentSession().delete(order);
		    return true;
		  }
		  catch(Exception E)
		  {
			  return false;
		  }
	}
//
//	
//	public Order getOrder(int id) 
//	{
//		if(order.getC_id()==id)
//			return order;
//		return null;
//	}
//
//	
//	public List<Order> list() {
//		return null;
//	}

}
