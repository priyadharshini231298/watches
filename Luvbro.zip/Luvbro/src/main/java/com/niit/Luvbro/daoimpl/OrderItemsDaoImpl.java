package com.niit.Luvbro.daoimpl;



//import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.niit.Luvbro.dao.OrderItemsDao;
import com.niit.Luvbro.model.OrderItems;
//import com.niit.Luvbro.model.Product;

@Repository("orderitemsDao")
@EnableTransactionManagement
@Transactional
public class OrderItemsDaoImpl implements OrderItemsDao 
{
  @Autowired
  private SessionFactory sessionFactory ;

	 public OrderItemsDaoImpl(SessionFactory sessionFactory)
	 {
		 this.sessionFactory = sessionFactory;
	 }

	public boolean saveOrUpdate(OrderItems orderitems) 
	{
	  try
	  {
	   sessionFactory.getCurrentSession().saveOrUpdate(orderitems);
	    return true;
	  }
	  catch(Exception E)
	  {
		  return false;
	  }
	}


	public boolean delete(OrderItems orderitems)
	{
		try
		  {
		   sessionFactory.getCurrentSession().delete(orderitems);
		    return true;
		  }
		  catch(Exception E)
		  {
			  return false;
		  }
	}
//
//	
//	public OrderItems getOrderItems(int id) 
//	{
//		if(orderitems.getC_id()==id)
//			return orderitems;
//		return null;
//	}
//
//	
//	public List<OrderItems> list() {
//		return null;
//	}

}
