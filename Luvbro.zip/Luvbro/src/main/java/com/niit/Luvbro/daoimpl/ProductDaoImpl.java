package com.niit.Luvbro.daoimpl;

//import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.niit.Luvbro.dao.ProductDao;
import com.niit.Luvbro.model.Product;

@Repository("productDao")
@EnableTransactionManagement
@Transactional
public class ProductDaoImpl implements ProductDao 
{
	Product product=null;
	SessionFactory sessionFactory;
 
	public ProductDaoImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory = sessionFactory;
	}
	
	public boolean saveOrUpdate(Product product) 
	{
		try
		  {
		   sessionFactory.getCurrentSession().saveOrUpdate(product);
		    return true;
		  }
		  catch(Exception E)
		  {
			  return false;
		  }
	}

	
	public boolean delete(Product product) 
	{
		try
		  {
		   sessionFactory.getCurrentSession().delete(product);
		    return true;
		  }
		  catch(Exception E)
		  {
			  return false;
		  }
	}
//
//	
//	public Product getProduct(int id) 
//	{
//		if(product.getP_id()==id)
//			return product;
//		return null;
//	}
//
//	
//	public List<Product> list() {
//		return null;
//	}

}
