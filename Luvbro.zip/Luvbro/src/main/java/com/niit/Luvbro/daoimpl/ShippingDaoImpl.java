package com.niit.Luvbro.daoimpl;



//import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.niit.Luvbro.dao.ShippingDao;
import com.niit.Luvbro.model.Shipping;
//import com.niit.Luvbro.model.Product;

@Repository("shippingDao")
@EnableTransactionManagement
@Transactional
public class ShippingDaoImpl implements ShippingDao 
{
  @Autowired
  private SessionFactory sessionFactory ;

	 public ShippingDaoImpl(SessionFactory sessionFactory)
	 {
		 this.sessionFactory = sessionFactory;
	 }

	public boolean saveOrUpdate(Shipping shipping) 
	{
	  try
	  {
	   sessionFactory.getCurrentSession().saveOrUpdate(shipping);
	    return true;
	  }
	  catch(Exception E)
	  {
		  return false;
	  }
	}


	public boolean delete(Shipping shipping)
	{
		try
		  {
		   sessionFactory.getCurrentSession().delete(shipping);
		    return true;
		  }
		  catch(Exception E)
		  {
			  return false;
		  }
	}
//
//	
//	public Shipping getShipping(int id) 
//	{
//		if(shipping.getC_id()==id)
//			return shipping;
//		return null;
//	}
//
//	
//	public List<Shipping> list() {
//		return null;
//	}

}
