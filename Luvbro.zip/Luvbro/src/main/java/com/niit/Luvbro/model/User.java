package com.niit.Luvbro.model;

//import java.util.List;

//import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
//import javax.persistence.OneToMany;
//import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="User")
@Component
public class User 
{
	@Id
	private String U_id;
	private String U_name;
	private int U_phoneno;
	private String U_address;
	private String U_email_addr;
	
	@OneToOne
	@JoinColumn(name="cart_Id")
	private Cart cart;
	
	@OneToOne
	@JoinColumn(name="b_Id")
	private Billing billing;
	
////	@OneToMany(mappedBy="user")
////	private List<Card> card;
//	
////	public List<Card> getCard() {
////		return card;
////	}
////	public void setCard(List<Card> card) {
////		this.card = card;
////	}
//	public Billing getBilling() {
//		return billing;
//	}
//	public void setBilling(Billing billing) {
//		this.billing = billing;
//	}
//	
//	public Cart getCart() {
//		return cart;
//	}
//	public void setCart(Cart cart) {
//		this.cart = cart;
//	}
	public String getU_name() {
		return U_name;
	}
	public Cart getCart() {
		return cart;
	}
	public void setCart(Cart cart) {
		this.cart = cart;
	}
	public Billing getBilling() {
		return billing;
	}
	public void setBilling(Billing billing) {
		this.billing = billing;
	}
	public void setU_name(String u_name) {
		U_name = u_name;
	}
	public String getU_id() {
		return U_id;
	}
	public void setU_id(String u_id) {
		U_id = u_id;
	}
	public int getU_phoneno() {
		return U_phoneno;
	}
	public void setU_phoneno(int u_phoneno) {
		U_phoneno = u_phoneno;
	}
	public String getU_address() {
		return U_address;
	}
	public void setU_address(String u_address) {
		U_address = u_address;
	}
	public String getU_email_addr() {
		return U_email_addr;
	}
	public void setU_email_addr(String u_email_addr) {
		U_email_addr = u_email_addr;
	}
	

}
