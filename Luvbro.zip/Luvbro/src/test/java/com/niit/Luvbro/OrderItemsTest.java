package com.niit.Luvbro;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

//import com.niit.Luvbro.dao.OrderDao;
import com.niit.Luvbro.dao.OrderItemsDao;
//import com.niit.Luvbro.daoimpl.UserDaoImpl;
import com.niit.Luvbro.model.OrderItems;

public class OrderItemsTest 
{
	public static void main(String a[])
	{
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		  context.scan("com.niit.Luvbro.*");
		  context.refresh();
	
	OrderItems orderitems = (OrderItems)context.getBean("orderItems");
	
	orderitems.setOrderitem_id("28");
	orderitems.setP_id("1");
	
	OrderItemsDao orderitemsDao =(OrderItemsDao) context.getBean("orderitemsDao"); //new UserDaoImpl();
	if(orderitemsDao.saveOrUpdate(orderitems))
	{
		System.out.println("save is successfull");
	}
	else
	{
		System.out.println("Sorry");
	}
//	 usr=userdao.getUser(10);
//		if(usr != null)
//		{
//			System.out.println("user found successfully");
//		}
//		else
//		{
//			System.out.println("user not found");
//		}
		if(orderitemsDao.delete(orderitems))
		{
			System.out.println("id deleted successfull");
		}
		else
		{
			System.out.println("sorry");
		
		}
	context.close();
	  
	}
}

