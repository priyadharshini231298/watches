package com.niit.Luvbro;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.Luvbro.dao.OrderDao;
//import com.niit.Luvbro.daoimpl.UserDaoImpl;
import com.niit.Luvbro.model.Order;

public class OrderTest 
{
	public static void main(String a[])
	{
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		  context.scan("com.niit.Luvbro.*");
		  context.refresh();
	
	Order order = (Order)context.getBean("order");
	
	order.setO_id("92");
	order.setO_orddate("12/06/2017");
	order.setO_ordtime("06:25:12");
	order.setO_grandtotal(76230);
	
	OrderDao orderDao =(OrderDao) context.getBean("orderDao"); //new UserDaoImpl();
	if(orderDao.saveOrUpdate(order))
	{
		System.out.println("save is successfull");
	}
	else
	{
		System.out.println("Sorry");
	}
//	 usr=userdao.getUser(10);
//		if(usr != null)
//		{
//			System.out.println("user found successfully");
//		}
//		else
//		{
//			System.out.println("user not found");
//		}
		if(orderDao.delete(order))
		{
			System.out.println("id deleted successfull");
		}
		else
		{
			System.out.println("sorry");
		
		}
	context.close();
	  
	}
}
