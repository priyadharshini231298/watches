package com.niit.Luvbro;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.Luvbro.dao.ProductDao;
//import com.niit.Luvbro.daoimpl.ProductDaoImpl;
import com.niit.Luvbro.model.Product;

public class ProductTest 
{
	public static void main(String a[])
	{
		 AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		  context.scan("com.niit.Luvbro.*");
		  context.refresh();

		Product product = (Product)context.getBean("product");
		ProductDao productDao = (ProductDao) context.getBean("productDao");
		
		product.setP_id("1");
		product.setP_name("Dairymilk");
		product.setP_q(23);
		product.setP_c(50.00f);
		product.setDes("choclate that makes us feel that we are in heaven");
		
		if(productDao.saveOrUpdate(product))
		{
			System.out.println("save is successfull");
		}
		else
		{
			System.out.println("sorry");
		}
		
//		
//		  pro=productdao.getProduct(1);
//		if(pro != null)
//		{
//			System.out.println("product found s uccessfully");
//		}
//		else
//		{
//			System.out.println("product not found");
//		}
		if(productDao.delete(product))
		{
			System.out.println("id deleted successfull");
		}
		else
		{
			System.out.println("sorry");
		
		}
		context.close();
	}

}
