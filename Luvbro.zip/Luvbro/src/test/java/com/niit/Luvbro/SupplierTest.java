package com.niit.Luvbro;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

//import com.niit.Luvbro.dao.ProductDao;
import com.niit.Luvbro.dao.SupplierDao;
//import com.niit.Luvbro.daoimpl.ProductDaoImpl;
//import com.niit.Luvbro.daoimpl.SupplierDaoImpl;
import com.niit.Luvbro.model.Supplier;

public class SupplierTest 
{
	public static void main(String a[])
	{
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		  context.scan("com.niit.Luvbro.*");
		  context.refresh();
		Supplier  s=new Supplier();
		s.setS_id("100");
		s.setS_name("Ramya");
		s.setS_num(990008919);
		s.setS_product("Dairy Milk");
		SupplierDao supplierDao = (SupplierDao)context.getBean("supplierDao");
		if(supplierDao.saveOrUpdate(s))
		{
			System.out.println("save is successfull");
		}
		else
		{
			System.out.println("sorry");
		}
		
//		  sup=supplierdao.getSupplier(1);
//		if(sup != null)
//		{
//			System.out.println("Supplier found successfully");
//		}
//		else
//		{
//			System.out.println("supplier not found");
//		}
		if(supplierDao.delete(s))
		{
			System.out.println("id deleted successfull");
		}
		else
		{
			System.out.println("sorry");
		
		}

		context.close();
	}

}
