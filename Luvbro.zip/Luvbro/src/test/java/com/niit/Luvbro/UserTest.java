package com.niit.Luvbro;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.Luvbro.dao.UserDao;
//import com.niit.Luvbro.model.Billing;
//import com.niit.Luvbro.model.Cart;
//import com.niit.Luvbro.daoimpl.UserDaoImpl;
import com.niit.Luvbro.model.User;

public class UserTest 
{
	public static void main(String a[])
	{
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		  context.scan("com.niit.Luvbro.*");
		  context.refresh();
	
	User user = (User)context.getBean("user");
	UserDao userDao =(UserDao) context.getBean("userDao"); //new UserDaoImpl();


	
	
	user.setU_id("10");
	user.setU_name("Priyadharshini");
	user.setU_phoneno(990008919);
	user.setU_email_addr("priyadharshini231298@gmail.com");
	user.setU_address("#217,Ist main,6th cross,prakashnagar,bangalore-21");
	
	
	if(userDao.saveOrUpdate(user))
	{
		System.out.println("save is successfull");
	}
	else
	{
		System.out.println("Sorry");
	}
//	 usr=userdao.getUser(10);
//		if(usr != null)
//		{
//			System.out.println("user found successfully");
//		}
//		else
//		{
//			System.out.println("user not found");
//		}
		if(userDao.delete(user))
		{
			System.out.println("id deleted successfull");
		}
		else
		{
			System.out.println("sorry");
		
		}
	context.close();
	  
	}
}
